# Redux Real World Example

> **Warning**: This example is outdated, and shows legacy patterns that we no longer teach or recommend.
> Please see the Redux docs tutorials for our recommended usage patterns, and specifically the "Essentials" tutorial:
> **https://redux.js.org/tutorials/index**
