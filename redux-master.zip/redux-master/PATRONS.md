# Patrons

The work on Redux was [funded by the community](https://www.patreon.com/reactdx).  
Meet some of the outstanding companies and individuals that made it possible:

- [Webflow](https://github.com/webflow)
- [Ximedes](https://www.ximedes.com/)
- [HauteLook](https://hautelook.github.io/)
- [Ken Wheeler](https://kenwheeler.github.io/)
- [Chung Yen Li](https://www.facebook.com/prototocal.lee)
- [Sunil Pai](https://twitter.com/threepointone)
- [Charlie Cheever](https://twitter.com/ccheever)
- [Eugene G](https://twitter.com/e1g)
- [Matt Apperson](https://twitter.com/mattapperson)
- [Jed Watson](https://twitter.com/jedwatson)
- [Sasha Aickin](https://twitter.com/xander76)
- [Stefan Tennigkeit](https://twitter.com/whobubble)
- [Sam Vincent](https://twitter.com/samvincent)
- Olegzandr Denman
