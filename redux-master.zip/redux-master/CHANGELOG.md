# Change Log

This project adheres to [Semantic Versioning](https://semver.org/).  
Every release, along with the migration instructions, is documented on the Github [Releases](https://github.com/reduxjs/redux/releases) page.
